const hideLoader = () => {
  document.querySelector('#loader').style.display = 'none';
};

export default hideLoader;
